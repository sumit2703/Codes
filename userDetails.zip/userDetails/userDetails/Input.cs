﻿using System;
using System.Collections.Generic;
using System.Text;

namespace userDetails
{
    class Input <T>
    {
        public T input;
        public Input()
        {

        }
    }
}
