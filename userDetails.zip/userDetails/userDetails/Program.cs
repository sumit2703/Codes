﻿using System;
using System.Collections.Generic;

namespace userDetails
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Object> list = new List<Object>();
            string ans = "";
            UserInput();
            while (ans != "n")
            {
                UserInput();
            } 
  
            foreach (var item in list)
            {
                    Console.WriteLine(item);
            }
            void UserInput()
            {
                Console.WriteLine("Do you want to Add an Items(y/n)?");
                ans = Console.ReadLine();
                Console.WriteLine("Enter the input");
                var ip = Console.ReadLine();
                Console.WriteLine("Enter the type i for integer, s for string, b for Boolean");
                string t = Console.ReadLine();
                
                switch (t)
                {
                    case "i":
                        Input<int> intGenericClass = new Input<int>();
                        intGenericClass.input = int.Parse(ip);
                        list.Add(intGenericClass.input);
                        break;
                    case "s":
                        Input<string> intGenericClass1 = new Input<string>();
                        intGenericClass1.input = ip;
                        list.Add(intGenericClass1.input);
                        break;
                    case "b":
                        Input<bool> intGenericClass2 = new Input<bool>();
                        intGenericClass2.input = bool.Parse(ip);
                        list.Add(intGenericClass2.input);
                        break;
                    default:
                        break;
                }
            }
           
        }
    }
}
